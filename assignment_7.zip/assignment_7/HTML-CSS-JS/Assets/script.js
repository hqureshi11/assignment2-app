var currentDate = new Date();
console.log(currentDate);
var image;


if (currentDate.getDay() === 0){
    var SchenleyPlaza = new park("Schenley Plaza","Oakland",40.442947,-79.952407,
                                "great for dogs", "perfect for picnics", "no playground");
    var currentPark = Object.assign({name: "Schenley Plaza", neighborhood: "Oakland", feat1: "great for dogs", feat2: "perfect for picnics", con1: "no playground"}, SchenleyPlaza);
    console.log(currentPark);
    var myHome = {lat: 40.442947, lng: -79.952407};

    window.onload = function(){
        document.getElementById("imageBox").src = "https://i.imgur.com/rTeLcMB.jpg";
    }
}

if (currentDate.getDay() === 1){
    var SchenleyPark = new park("Schenley Park","Squirrel Hill",40.434883,-79.942510,
                                "is full of green space", "has walking trails", "has large deer population");
    var currentPark = Object.assign({name: "Schenley Park", neighborhood: "Squirrel Hill", feat1: "is full of green space", feat2: "has walking trails", con1: "has large deer population"}, SchenleyPark);
    console.log(currentPark);
    var myHome = {lat: 40.434883, lng: -79.942510};

    window.onload = function(){
        document.getElementById("imageBox").src = "https://i.imgur.com/iaZbR89.jpg";
    }
}

if (currentDate.getDay() === 2){
    var AlleghenyCommons = new park("Allegheny Commons","North Side",40.452086,-80.010802,
                              "is full of green space", "is full of attractions", "has parkways running through");
    var currentPark = Object.assign({name: "Allegheny Commons", neighborhood: "North Side", feat1: "is full of green space", feat2: "is full of attractions", con1: "has parkways"}, AlleghenyCommons);
    console.log(currentPark);
    var myHome = {lat: 40.452086, lng: -80.010802};

    window.onload = function(){
        document.getElementById("imageBox").src = "https://i.imgur.com/JCmf47g.jpg";
    }
}

if (currentDate.getDay() === 3){
    var FrickPark = new park("Frick Park","Point Breeze",40.436085,-79.908538, "is expansive and historic", "is perfect for hikers", "can be dangerous at night");
    var currentPark = Object.assign({name: "Frick Park", neighborhood: "Point Breeze", feat1: "is expansive and historic", feat2: "is perfect for hikers", con1: "can be dangerous at night"}, FrickPark);
    console.log(currentPark);
    var myHome = {lat: 40.436085, lng: -79.908538};

    window.onload = function(){
        document.getElementById("imageBox").src = "https://i.imgur.com/LtMCdwY.jpg";
    }
}

if (currentDate.getDay() === 4){
    var MellonPark = new park("Mellon Park","Shadyside",40.452050, -79.919020, "has tons of shade", "is great for lunch", "is located at a busy intersection");
    var currentPark = Object.assign({name: "Mellon Park", neighborhood: "Shadyside", feat1: "has tons of shade", feat2: "is great for lunch", con1: "is located at a busy intersection"}, MellonPark);
    console.log(currentPark);
    var myHome = {lat: 40.452050, lng: -79.919020};

    window.onload = function(){
        document.getElementById("imageBox").src = "https://i.imgur.com/Lx0Npi7.jpg";
    }
}

if (currentDate.getDay() === 5){
    var GardenOfHope = new park("Garden of Hope","The Hill District",40.452136,-79.971145, "has community gardening space", "is great for lunch", "is in an unsafe area");
    var currentPark = Object.assign({name: "Garden of Hope", neighborhood: "The Hill District", feat1: "has community gardening space", feat2: "is great for lunch", con1: "is in an unsafe area"}, GardenOfHope);
    console.log(currentPark);
    var myHome = {lat: 40.452136, lng: -79.971145};

    window.onload = function(){
        document.getElementById("imageBox").src = "https://i.imgur.com/Cm2ANS0.jpg";
    }
}

if (currentDate.getDay() === 6){
    var ArsenalPark = new park("Arsenal Park","Lawrenceville",40.466351,-79.961222, "has playground spaces", "has tons of shade", "is not in a family-friendly area");
    var currentPark = Object.assign({name: "Arsenal Park", neighborhood: "Lawrenceville", feat1: "has playground spaces", feat2: "has tons of shade", con1: "is not in a family-friendly area"}, ArsenalPark);
    console.log(currentPark);
    var myHome = {lat: 40.466351, lng: -79.961222};

    window.onload = function(){
        document.getElementById("imageBox").src = "https://i.imgur.com/6GplqLJ.jpg";
    }
}

function myMap() {
    var mapProp= {
        center: myHome,
        zoom:17,
    };
    var map = new google.maps.Map(googleMap,mapProp);
}

function park(name, neighborhood, lat, long, feat1, feat2, con1, image){
    this.name = name;
    this.neighborhood = neighborhood;
    this.lat = lat;
    this.long = long;
    this.feat1 = feat1;
    this.feat2 = feat2;
    this.con1 = con1;
    this.image = image;
}

